<template>
    <img src="/assets/images/logo.png" />
</template>
