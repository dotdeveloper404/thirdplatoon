@extends('layouts.frontend.app')

@section('content')

<section class="about-sec">
    <div class="col-md-6 about-left">
        <img src="assets/images/sec2-1.png">
    </div>
    <div class="col-md-6 about-right">
        <h2>ABOUT US</h2>
        <p>Nullam commodo dui ac pretium malesuada. Quisque eu consequat ligula. Curabitur at ante eros. Fusce
            maximus urna turpis, a commodo eros dapibus ac. Etiam nec tellus ullamcorper ante condimentum facilisis.
            Aenean nibh erat, accumsan non faucibus eu, aliquet id massa. Curabitur arcu ante, molestie ac odio at,
            laoreet eleifend metus. Praesent diam velit, efficitur id libero quis, lacinia hendrerit arcu llus
            ullamcorper ante condimentum.</p>

        <a href="#">READ MORE</a>
    </div>
</section>


@endsection