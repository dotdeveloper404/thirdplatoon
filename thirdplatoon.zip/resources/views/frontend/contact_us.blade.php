@extends('layouts.frontend.app')



@section('content')

<section class="news-section">
    <div class="container">
        <h5>From the blog</h5>
        <h3>News & Articles</h3>
        <p>Lorem ipsum dolor sit amet, cibo mundi ea duo, vim exerci phaedrum</p>

        <div class="col-md-4">
            <img src="assets/images/home-sec7-1.png" class="img-responsive">
        </div>
        <div class="col-md-4">
            <img src="assets/images/home-sec7-2.png" class="img-responsive">
        </div>
        <div class="col-md-4">
            <img src="assets/images/home-sec7-3.png" class="img-responsive">
        </div>
    </div>
</section>
<section class="blog-area">
    <div class="container">
        <div class="col-md-4 ">
            <div class="blog-text-area">
                <div class="col-md-10">
                    <ul>
                        <li>by Admin</li>
                        <li>2 Comments</li>
                    </ul>
                </div>
                <div class="col-md-2">
                    <h5>23 oct</h5>
                </div>

                <h4>Lorem ipsum dolor sit amet 1550s and the typeing.</h4>
                <p>Lorem ipsum dolor sit amet, cibo mundi ea duo, vim exerci phaedrum</p>
            </div>
        </div>

        <div class="col-md-4 ">
            <div class="blog-text-area">
                <div class="col-md-10">
                    <ul>
                        <li>by Admin</li>
                        <li>2 Comments</li>
                    </ul>
                </div>
                <div class="col-md-2">
                    <h5>23 oct</h5>
                </div>

                <h4>Lorem ipsum dolor sit amet 1550s and the typeing.</h4>
                <p>Lorem ipsum dolor sit amet, cibo mundi ea duo, vim exerci phaedrum</p>
            </div>
        </div>

        <div class="col-md-4 ">
            <div class="blog-text-area">
                <div class="col-md-10">
                    <ul>
                        <li>by Admin</li>
                        <li>2 Comments</li>
                    </ul>
                </div>
                <div class="col-md-2">
                    <h5>23 oct</h5>
                </div>

                <h4>Lorem ipsum dolor sit amet 1550s and the typeing.</h4>
                <p>Lorem ipsum dolor sit amet, cibo mundi ea duo, vim exerci phaedrum</p>
            </div>
        </div>



    </div>
</section>

@endsection