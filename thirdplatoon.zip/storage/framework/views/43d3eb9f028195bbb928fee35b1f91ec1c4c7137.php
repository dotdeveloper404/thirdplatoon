

<?php $__env->startSection('content'); ?>

<section class="about-sec">
    <div class="col-md-6 about-left">
        <img src="assets/images/sec2-1.png">
    </div>
    <div class="col-md-6 about-right">
        <h2>ABOUT US</h2>
        <p>Nullam commodo dui ac pretium malesuada. Quisque eu consequat ligula. Curabitur at ante eros. Fusce
            maximus urna turpis, a commodo eros dapibus ac. Etiam nec tellus ullamcorper ante condimentum facilisis.
            Aenean nibh erat, accumsan non faucibus eu, aliquet id massa. Curabitur arcu ante, molestie ac odio at,
            laoreet eleifend metus. Praesent diam velit, efficitur id libero quis, lacinia hendrerit arcu llus
            ullamcorper ante condimentum.</p>

        <a href="#">READ MORE</a>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\thirdplatoon\resources\views/frontend/about_us.blade.php ENDPATH**/ ?>