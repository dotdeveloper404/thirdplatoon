<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">



<?php echo $__env->make('layouts.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <section class="banner-area">

        <?php echo $__env->make('layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="banner-content-area">
            <h2>Discover the</h2>
            <h2>Best Jobs For You</h2>
            <h5>Find great ooportunities, hire and post jobs</h5>
            <a href="#">SEE POSTS</a>
        </div>

    </section>

    <section class="form-area">
        <div class="container">
            <form>
                <input type="text" name="" placeholder="Enter Keyword">

                <select>
                    <option>all categories</option>
                    <option>category 1</option>
                    <option>category 2</option>
                    <option>category 3</option>
                </select>

                <input type="text" name="">
                <select>
                    <option>select price rating</option>
                    <option> 1</option>
                    <option> 2</option>
                    <option> 3</option>
                </select>

                <input type="submit" name="" value="search">
            </form>
        </div>
    </section>


    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH E:\xampp\htdocs\thirdplatoon\resources\views/layouts/app.blade.php ENDPATH**/ ?>