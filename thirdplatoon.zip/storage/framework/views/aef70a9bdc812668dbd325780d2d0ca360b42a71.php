<a href="/">
    <img src="assets/images/logo.png" />
</a><?php /**PATH E:\xampp\htdocs\thirdplatoon\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>